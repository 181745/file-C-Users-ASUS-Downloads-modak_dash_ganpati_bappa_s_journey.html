import * as THREE from "three";

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87c8f7);
scene.fog = new THREE.Fog(0x87c8f7, 42, 170);

const camera = new THREE.PerspectiveCamera(63, innerWidth / innerHeight, 0.1, 260);
camera.position.set(0, 3.65, 9.2);

const renderer = new THREE.WebGLRenderer({antialias:true, powerPreference:"high-performance"});
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
document.body.appendChild(renderer.domElement);

const hemi = new THREE.HemisphereLight(0xffefd3, 0x3e241c, 2.7);
scene.add(hemi);

const sun = new THREE.DirectionalLight(0xffe1bc, 3.0);
sun.position.set(24, 30, 20);
sun.castShadow = true;
sun.shadow.mapSize.set(1024,1024);
sun.shadow.camera.left=-40; sun.shadow.camera.right=40;
sun.shadow.camera.top=35; sun.shadow.camera.bottom=-10;
scene.add(sun);

const fill = new THREE.PointLight(0xff9c45, 1.1, 85);
fill.position.set(0,7,-55);
scene.add(fill);

const world = new THREE.Group();
scene.add(world);
const roadGroup = new THREE.Group();
const housesGroup = new THREE.Group();
const landmarkGroup = new THREE.Group();
const objectGroup = new THREE.Group();
world.add(roadGroup,housesGroup,landmarkGroup,objectGroup);

const laneX = [-3.7,0,3.7];
const roadSegments=[];
const runners=[];
const collectibles=[];
const powerups=[];

let running=false, paused=false, ended=false;
let lane=1, targetX=0;
let speed=19, distance=0, score=0, modaks=0, durva=0, combo=1, comboTimer=0, lives=3;
let spawnTimer=.7, collectibleTimer=.2, powerTimer=9;
let jumpY=0, yVel=0, slideTimer=0;
let shield=0, magnet=0;
let messageTimer;

const clock = new THREE.Clock();
const player = create3DGanesha();
player.position.set(0,0,5.0);
scene.add(player);

buildEnvironment();
updateHUD();

document.getElementById("startBtn").onclick=()=>{resetGame();document.getElementById("startScreen").classList.add("hidden");running=true;};
document.getElementById("pauseBtn").onclick=togglePause;
document.getElementById("resumeBtn").onclick=togglePause;
document.getElementById("restartBtn").onclick=restartGame;
document.getElementById("againBtn").onclick=restartGame;

addEventListener("keydown",e=>{
  if(["ArrowLeft","ArrowRight","ArrowUp","ArrowDown","Space"].includes(e.code))e.preventDefault();
  if(e.repeat||!running||paused)return;
  if(e.code==="ArrowLeft"||e.code==="KeyA")changeLane(-1);
  if(e.code==="ArrowRight"||e.code==="KeyD")changeLane(1);
  if(e.code==="ArrowUp"||e.code==="Space"||e.code==="KeyW")jump();
  if(e.code==="ArrowDown"||e.code==="KeyS")slide();
});

renderer.domElement.addEventListener("pointerdown",e=>{
  if(!running||paused)return;
  if(e.clientX<innerWidth/2)changeLane(-1);else changeLane(1);
});

function changeLane(dir){
  const next=THREE.MathUtils.clamp(lane+dir,0,2);
  if(next===lane)return;
  lane=next;
  targetX=laneX[lane];
  player.position.x=targetX;
  player.userData.laneKick=dir;
  pulse(1);
}

function jump(){
  if(jumpY<=.01 && slideTimer<=0) yVel=11.8;
}

function slide(){
  if(jumpY<.25) slideTimer=.72;
}

function togglePause(){
  if(!running||ended)return;
  paused=!paused;
  document.getElementById("pauseScreen").classList.toggle("hidden",!paused);
}

function restartGame(){
  document.getElementById("pauseScreen").classList.add("hidden");
  document.getElementById("gameOverScreen").classList.add("hidden");
  resetGame(); running=true;
}

function resetGame(){
  running=false;paused=false;ended=false;
  speed=19;distance=0;score=0;modaks=0;durva=0;combo=1;comboTimer=0;lives=3;
  lane=1;targetX=0;jumpY=0;yVel=0;slideTimer=0;shield=0;magnet=0;
  spawnTimer=.6;collectibleTimer=.1;powerTimer=9;
  player.position.set(0,0,5.0);
  player.rotation.set(0,0,0);
  for(const x of [...runners])removeObj(x.group,runners);
  for(const x of [...collectibles])removeObj(x.group,collectibles);
  for(const x of [...powerups])removeObj(x.group,powerups);
  updateHUD();
}

function endGame(reason){
  running=false;ended=true;
  document.getElementById("reason").textContent=reason;
  document.getElementById("finalModaks").textContent=modaks;
  document.getElementById("finalScore").textContent=Math.floor(score).toLocaleString();
  document.getElementById("finalDistance").textContent=Math.floor(distance)+"m";
  document.getElementById("gameOverScreen").classList.remove("hidden");
}

function update(dt){
  if(!running||paused)return;

  speed=Math.min(32,speed+dt*.34);
  distance+=speed*dt*.95;
  score+=speed*dt*2.8;

  comboTimer-=dt;
  if(comboTimer<=0)combo=1;
  slideTimer=Math.max(0,slideTimer-dt);

  yVel-=29*dt;
  jumpY+=yVel*dt;
  if(jumpY<=0){jumpY=0;yVel=0;}

  animateGanesha(dt);

  for(const seg of roadSegments){
    seg.position.z+=speed*dt;
    if(seg.position.z>31)seg.position.z-=280;
  }

  for(const pair of housesGroup.children){
    pair.position.z+=speed*dt;
    if(pair.position.z>30)pair.position.z-=280;
  }

  landmarkGroup.position.z+=speed*dt*.97;
  if(landmarkGroup.position.z>60)landmarkGroup.position.z-=290;

  for(const o of runners)o.group.position.z+=speed*dt;
  for(const c of collectibles){
    c.group.position.z+=speed*dt;
    c.group.rotation.y+=dt*2.2;
    c.group.position.y=c.baseY+Math.sin(performance.now()*.004+c.phase)*.14;
    if(magnet>0 && c.type==="modak"){
      const dx=player.position.x-c.group.position.x, dz=player.position.z-c.group.position.z;
      if(Math.hypot(dx,dz)<7){
        c.group.position.x=THREE.MathUtils.damp(c.group.position.x,player.position.x,12,dt);
        c.group.position.z=THREE.MathUtils.damp(c.group.position.z,player.position.z,12,dt);
      }
    }
  }
  for(const p of powerups){
    p.group.position.z+=speed*dt;
    p.group.rotation.y+=dt*2.3;
    p.group.position.y=1.75+Math.sin(performance.now()*.004+p.phase)*.15;
  }

  spawnTimer-=dt; collectibleTimer-=dt; powerTimer-=dt;
  if(spawnTimer<=0){spawnObstaclePattern();spawnTimer=Math.max(.62,1.08-speed*.012)*(0.82+Math.random()*.4);}
  if(collectibleTimer<=0){spawnCollectibleLine();collectibleTimer=.62+Math.random()*.5;}
  if(powerTimer<=0){spawnPowerup();powerTimer=12+Math.random()*9;}

  collisions();
  cleanup();

  player.position.x=targetX;
  camera.position.x=THREE.MathUtils.damp(camera.position.x,targetX*.1,22,dt);
  camera.position.y=THREE.MathUtils.damp(camera.position.y,3.6+(jumpY*.1),18,dt);
  camera.lookAt(targetX*.07,2.05,-4.8);

  updateHUD();
}

function animateGanesha(dt){
  const t=performance.now()*.008;
  const runBlend=slideTimer>0?0.2:1;
  player.position.y=jumpY + (jumpY===0 ? Math.abs(Math.sin(t))*0.035 : 0);

  const body=player.userData.body;
  const head=player.userData.head;
  const arms=player.userData.arms;
  const legs=player.userData.legs;
  const crown=player.userData.crown;

  if(slideTimer>0){
    body.position.y=1.25; head.position.y=1.95; crown.position.y=2.42;
    body.scale.set(.95,.66,1.1);
    arms.forEach((a,i)=>a.rotation.z=(i%2===0?-.45:.45));
    legs[0].rotation.x=-.5; legs[1].rotation.x=.5;
  }else{
    body.position.y=1.55; head.position.y=2.42; crown.position.y=2.96;
    body.scale.set(1,1,1);
    arms.forEach((a,i)=>{
      const swing=Math.sin(t*1.5 + i)*.18*runBlend;
      a.rotation.x=i<2?(.35+swing):(.6-swing);
      a.rotation.z=i%2===0?-.12:.12;
    });
    legs[0].rotation.x=Math.sin(t*1.55)*.42*runBlend;
    legs[1].rotation.x=-Math.sin(t*1.55)*.42*runBlend;
  }

  const laneKick=player.userData.laneKick||0;
  player.rotation.y=THREE.MathUtils.damp(player.rotation.y,laneKick*.08,15,dt);
  player.userData.laneKick=0;
}

function collisions(){
  const playerBox=new THREE.Box3().setFromCenterAndSize(
    new THREE.Vector3(player.position.x,player.position.y+1.35,player.position.z),
    new THREE.Vector3(slideTimer>0?1.3:1.15,slideTimer>0?1.25:2.8,.9)
  );

  for(const o of runners){
    if(o.hit || Math.abs(o.group.position.z-player.position.z)>2.5)continue;
    const box=new THREE.Box3().setFromObject(o.group);box.expandByScalar(-.14);
    if(playerBox.intersectsBox(box)){
      o.hit=true;o.group.visible=false;
      if(shield>0){shield=0;showMessage("🛡️ SAVED!");}
      else{
        lives--;combo=1;showMessage("💥 OOPS!");
        if(lives<=0){endGame("Three collisions. Try chaining your jumps and slides.");}
      }
    }
  }

  for(const c of collectibles){
    if(c.collected||Math.abs(c.group.position.z-player.position.z)>2.4)continue;
    if(Math.abs(c.group.position.x-player.position.x)<1.2 && Math.abs(c.group.position.y-(player.position.y+1.6))<1.9){
      c.collected=true;c.group.visible=false;
      if(c.type==="modak"){modaks++;combo=Math.min(8,combo+1);comboTimer=2.5;score+=100*combo;showMessage("🍥 MODAK!");}
      else{durva++;shield=Math.min(2,shield+1);score+=150;showMessage("🌿 SHIELD!");}
    }
  }

  for(const p of powerups){
    if(p.collected||Math.abs(p.group.position.z-player.position.z)>2.4)continue;
    if(Math.abs(p.group.position.x-player.position.x)<1.25 && Math.abs(p.group.position.y-(player.position.y+1.5))<1.9){
      p.collected=true;p.group.visible=false;
      if(p.type==="magnet"){magnet=1;showMessage("🧲 MAGNET!");}
      else{shield=Math.min(2,shield+1);showMessage("🛡️ BAPPA BLESSING!");}
      score+=250;
    }
  }
}

function spawnObstaclePattern(){
  const r=Math.random(),l=Math.floor(Math.random()*3);
  if(r<.2){spawnObstacle("log",l,-110);}
  else if(r<.4){spawnObstacle("cart",l,-110);}
  else if(r<.58){spawnObstacle("elephant",l,-110);}
  else if(r<.76){spawnObstacle("lowBarrier",l,-110);}
  else if(r<.9){
    const safe=Math.floor(Math.random()*3);
    for(let i=0;i<3;i++)if(i!==safe)spawnObstacle("cart",i,-110);
  }else spawnObstacle("dhol",l,-110);
}

function spawnObstacle(type,lane,z){
  const g=createObstacle(type);
  g.position.set(laneX[lane],0,z);
  objectGroup.add(g);
  runners.push({group:g,type,hit:false});
}

function spawnCollectibleLine(){
  const l=Math.floor(Math.random()*3),z=-105;
  for(let i=0;i<4;i++){
    const g=createModak();
    g.position.set(laneX[l],1.75+(i%2)*.2,z-i*4);
    objectGroup.add(g);
    collectibles.push({group:g,type:"modak",baseY:g.position.y,phase:Math.random()*6.28,collected:false});
  }
  if(Math.random()<.22){
    const l2=(l+1+Math.floor(Math.random()*2))%3;
    const g=createDurva();g.position.set(laneX[l2],1.95,z-10);objectGroup.add(g);
    collectibles.push({group:g,type:"durva",baseY:1.95,phase:Math.random()*6.28,collected:false});
  }
}

function spawnPowerup(){
  const l=Math.floor(Math.random()*3),type=Math.random()<.5?"magnet":"shield";
  const g=createPowerup(type);g.position.set(laneX[l],1.9,-118);objectGroup.add(g);
  powerups.push({group:g,type,phase:Math.random()*6.28,collected:false});
}

function cleanup(){
  for(const arr of [runners,collectibles,powerups]){
    for(const x of [...arr])if(x.collected||x.group.position.z>20)removeObj(x.group,arr);
  }
}

function removeObj(group,arr){
  const i=arr.findIndex(v=>v.group===group);if(i>=0)arr.splice(i,1);
  objectGroup.remove(group);
}

function buildEnvironment(){
  for(let i=0;i<10;i++){
    const road=makeRoadSegment();
    road.position.z=-i*28;roadGroup.add(road);roadSegments.push(road);
    const houses=makeHousePair();
    houses.position.z=-i*28;housesGroup.add(houses);
  }
  landmarkGroup.add(makeGrandPandal());
  landmarkGroup.position.z=-55;
}

function makeRoadSegment(){
  const g=new THREE.Group();
  const road=new THREE.Mesh(new THREE.PlaneGeometry(10.8,28),new THREE.MeshStandardMaterial({color:0x5b524b,roughness:.95}));
  road.rotation.x=-Math.PI/2;road.position.y=-.7;road.receiveShadow=true;g.add(road);

  const curbMat=new THREE.MeshStandardMaterial({color:0xb34d2f,roughness:.9});
  for(const x of [-5.6,5.6]){
    const c=new THREE.Mesh(new THREE.BoxGeometry(.38,.35,28),curbMat);
    c.position.set(x,-.52,0);g.add(c);
  }

  const stripe=new THREE.MeshStandardMaterial({color:0xe0ccb2});
  for(const x of [-1.85,1.85]){
    for(let z=-12;z<14;z+=4){
      const s=new THREE.Mesh(new THREE.BoxGeometry(.07,.02,1.65),stripe);
      s.position.set(x,-.49,z);g.add(s);
    }
  }
  return g;
}

function makeHousePair(){
  const g=new THREE.Group();
  g.add(makeHouse(-9.4,true));
  g.add(makeHouse(9.4,false));
  return g;
}

function makeHouse(x,left){
  const g=new THREE.Group();
  const h=6+Math.random()*1.6;
  const d=13.5;
  const colors=left?[0xc66a4d,0xa75e68,0xd09b55]:[0x4f7b80,0xb36a46,0x8a6694];
  const body=new THREE.Mesh(new THREE.BoxGeometry(6.2,h,d),new THREE.MeshStandardMaterial({color:random(colors),roughness:.9}));
  body.position.set(x,h/2-.55,0);body.castShadow=true;body.receiveShadow=true;g.add(body);

  const roof=new THREE.Mesh(new THREE.BoxGeometry(6.45,.42,d+.35),new THREE.MeshStandardMaterial({color:0x4b3229,roughness:.95}));
  roof.position.set(x,h-.28,0);g.add(roof);

  for(let r=0;r<2;r++){
    for(let c=0;c<2;c++){
      const w=new THREE.Mesh(new THREE.BoxGeometry(1.15,1.2,.14),new THREE.MeshStandardMaterial({color:0xd9ccb4,roughness:.96}));
      w.position.set(x-1.65+c*3.3,1.45+r*2.05,(left?-1:1)*(-d/2-.08));g.add(w);
    }
  }

  const door=new THREE.Mesh(new THREE.BoxGeometry(1.15,2.3,.18),new THREE.MeshStandardMaterial({color:0x6b3c2b,roughness:.95}));
  door.position.set(x,1.08,(left?-1:1)*(-d/2-.1));g.add(door);

  const garlandMat=new THREE.MeshStandardMaterial({color:0xffac2d,roughness:.95});
  const curve=new THREE.CatmullRomCurve3([
    new THREE.Vector3(x-2.45*(left?1:-1),h-.8,(left?-1:1)*(-d/2-.25)),
    new THREE.Vector3(x,h-1.75,(left?-1:1)*(-d/2-.3)),
    new THREE.Vector3(x+2.45*(left?1:-1),h-.8,(left?-1:1)*(-d/2-.25))
  ]);
  g.add(new THREE.Mesh(new THREE.TubeGeometry(curve,18,.055,6,false),garlandMat));

  for(let i=0;i<7;i++){
    const f=new THREE.Mesh(new THREE.ConeGeometry(.11,.4,4),new THREE.MeshStandardMaterial({color:random([0xf24d3a,0xf2c84b,0x4aa18b,0xa75d8d]),roughness:.9}));
    f.position.set(x-2.55+i*.85,h-.48-Math.sin(i*.8)*.07,(left?-1:1)*(-d/2-.28));
    f.rotation.z=left?-Math.PI/2:Math.PI/2;g.add(f);
  }

  const rangoli=makeRangoli();
  rangoli.position.set(x,-.5,(left?-1:1)*(-d/2-.36));g.add(rangoli);

  return g;
}

function makeRangoli(){
  const g=new THREE.Group();
  const base=new THREE.Mesh(new THREE.CylinderGeometry(.75,.75,.03,32),new THREE.MeshStandardMaterial({color:random([0xe65745,0xd1ad43,0x3f9b82]),roughness:.95}));
  g.add(base);
  for(let i=0;i<8;i++){
    const p=new THREE.Mesh(new THREE.SphereGeometry(.14,10,8),new THREE.MeshStandardMaterial({color:i%2?0xffffff:0xffd6a0,roughness:.96}));
    const a=i*Math.PI/4;p.position.set(Math.cos(a)*.42,.03,Math.sin(a)*.42);p.scale.set(1.2,.25,.75);g.add(p);
  }
  return g;
}

function makeGrandPandal(){
  const g=new THREE.Group();
  const wall=new THREE.Mesh(new THREE.BoxGeometry(17,9,1),new THREE.MeshStandardMaterial({color:0x963b30,roughness:.9}));
  wall.position.set(0,3.6,-35);g.add(wall);

  const canopy=new THREE.Mesh(new THREE.BoxGeometry(17.6,1.1,1.15),new THREE.MeshStandardMaterial({color:0xd8aa4d,roughness:.48,metalness:.12}));
  canopy.position.set(0,7.7,-34.6);g.add(canopy);

  const idol=makeDistantGanesha();
  idol.position.set(0,0.25,-33.8);idol.scale.setScalar(2.7);g.add(idol);

  const halo=new THREE.Mesh(new THREE.TorusGeometry(4.25,.18,12,64),new THREE.MeshStandardMaterial({color:0xffd36b,emissive:0xffa11a,emissiveIntensity:1.5,roughness:.3}));
  halo.position.set(0,4.6,-32.9);halo.rotation.x=Math.PI/2;g.add(halo);

  for(const side of [-1,1]){
    const drape=new THREE.Mesh(new THREE.BoxGeometry(1.8,7,.65),new THREE.MeshStandardMaterial({color:side<0?0xe2a43b:0xc84434,roughness:.84}));
    drape.position.set(side*7.0,2.55,-34.2);g.add(drape);
  }
  return g;
}

function makeDistantGanesha(){
  const g=new THREE.Group();
  const skin=new THREE.MeshStandardMaterial({color:0xe29a5b,roughness:.92});
  const cloth=new THREE.MeshStandardMaterial({color:0xd44533,roughness:.84});
  const gold=new THREE.MeshStandardMaterial({color:0xe8c35b,metalness:.2,roughness:.38});

  const body=new THREE.Mesh(new THREE.SphereGeometry(1,20,16),cloth);body.position.y=1.2;g.add(body);
  const head=new THREE.Mesh(new THREE.SphereGeometry(.74,20,16),skin);head.position.y=2.25;g.add(head);
  for(const s of [-1,1]){
    const ear=new THREE.Mesh(new THREE.SphereGeometry(.46,16,12),skin);ear.position.set(s*.6,2.3,0);ear.scale.x=.9;g.add(ear);
    const arm=new THREE.Mesh(new THREE.CylinderGeometry(.12,.14,.85,10),skin);arm.position.set(s*1.0,1.55,0);arm.rotation.z=s*.6;g.add(arm);
    const eye=new THREE.Mesh(new THREE.SphereGeometry(.065,10,8),new THREE.MeshStandardMaterial({color:0x24130e}));eye.position.set(s*.22,2.38,-.67);g.add(eye);
  }
  const trunk=new THREE.Mesh(new THREE.CapsuleGeometry(.14,.72,6,12),skin);trunk.position.set(0,1.85,-.6);trunk.rotation.x=.18;g.add(trunk);
  const crown=new THREE.Mesh(new THREE.ConeGeometry(.55,.82,12),gold);crown.position.y=3.15;g.add(crown);
  return g;
}

function create3DGanesha(){
  const root=new THREE.Group();
  root.scale.setScalar(1.0);

  const skin=new THREE.MeshStandardMaterial({color:0xe69759,roughness:.86});
  const inner=new THREE.MeshStandardMaterial({color:0xd47b47,roughness:.9});
  const gold=new THREE.MeshStandardMaterial({color:0xe8c557,metalness:.25,roughness:.32});
  const red=new THREE.MeshStandardMaterial({color:0xc92f37,roughness:.78});
  const green=new THREE.MeshStandardMaterial({color:0x2f7f63,roughness:.78});
  const brown=new THREE.MeshStandardMaterial({color:0x5a3524,roughness:.9});

  // Lower garment / dhoti.
  const dhoti=new THREE.Mesh(new THREE.CapsuleGeometry(.62,.78,8,18),red);
  dhoti.position.y=1.05;dhoti.scale.set(1.2,.8,.9);dhoti.castShadow=true;root.add(dhoti);

  // Waist sash.
  const sash=new THREE.Mesh(new THREE.TorusGeometry(.62,.10,10,32),green);
  sash.rotation.x=Math.PI/2;sash.position.y=1.55;root.add(sash);

  // Belly/body.
  const body=new THREE.Mesh(new THREE.SphereGeometry(.7,24,18),skin);
  body.position.y=1.6;body.scale.set(1.0,1.08,.85);body.castShadow=true;root.add(body);

  // Shoulders.
  const shoulder=new THREE.Mesh(new THREE.SphereGeometry(.52,20,16),skin);
  shoulder.position.y=2.2;shoulder.scale.set(1.1,.72,.75);root.add(shoulder);

  // Head.
  const head=new THREE.Mesh(new THREE.SphereGeometry(.62,28,22),skin);
  head.position.y=2.65;head.scale.set(.98,1.03,.94);head.castShadow=true;root.add(head);

  // Ears.
  for(const s of [-1,1]){
    const e=new THREE.Mesh(new THREE.SphereGeometry(.40,18,14),skin);
    e.position.set(s*.62,2.68,-.02);e.scale.set(.95,1.1,.38);root.add(e);
    const ie=new THREE.Mesh(new THREE.SphereGeometry(.23,14,10),inner);
    ie.position.set(s*.62,2.68,-.22);ie.scale.set(.95,1.05,.35);root.add(ie);
  }

  // Eyes.
  for(const s of [-1,1]){
    const eye=new THREE.Mesh(new THREE.SphereGeometry(.055,10,8),new THREE.MeshStandardMaterial({color:0x17100d}));
    eye.position.set(s*.21,2.78,-.56);root.add(eye);
    const brow=new THREE.Mesh(new THREE.TorusGeometry(.11,.025,6,16),red);
    brow.scale.x=.7;brow.position.set(s*.21,2.89,-.54);brow.rotation.x=Math.PI/2;root.add(brow);
  }

  // Trunk — broad, curved and very visible.
  const trunkCurve=new THREE.CatmullRomCurve3([
    new THREE.Vector3(0,2.56,-.54),
    new THREE.Vector3(0,2.28,-.72),
    new THREE.Vector3(.08,2.06,-.64),
    new THREE.Vector3(.16,1.98,-.48)
  ]);
  const trunk=new THREE.Mesh(new THREE.TubeGeometry(trunkCurve,22,.13,10,false),skin);
  trunk.castShadow=true;root.add(trunk);

  // Crown.
  const crown=new THREE.Mesh(new THREE.ConeGeometry(.58,.82,12),gold);
  crown.position.y=3.43;crown.castShadow=true;root.userData.crown=crown;root.add(crown);
  const crownBand=new THREE.Mesh(new THREE.TorusGeometry(.5,.075,8,28),gold);
  crownBand.rotation.x=Math.PI/2;crownBand.position.y=3.18;root.add(crownBand);
  const jewel=new THREE.Mesh(new THREE.SphereGeometry(.09,12,10),red);
  jewel.position.set(0,3.45,-.45);root.add(jewel);

  // Four arms, with two upper blessing poses and two lower running poses.
  const arms=[];
  const armPositions=[[-.7,2.15,-.05],[.7,2.15,-.05],[-.72,1.82,.15],[.72,1.82,.15]];
  armPositions.forEach((pos,i)=>{
    const upper=new THREE.Mesh(new THREE.CapsuleGeometry(.10,.56,6,10),skin);
    upper.position.set(pos[0],pos[1],pos[2]);
    upper.rotation.z=i%2?-.55:.55;
    upper.rotation.x=i<2?-.35:.35;
    upper.castShadow=true;
    root.add(upper);

    const hand=new THREE.Mesh(new THREE.SphereGeometry(.14,12,10),skin);
    hand.position.set(pos[0]+(i%2?-.22:.22),pos[1]+(i<2?.28:-.08),pos[2]-.02);
    root.add(hand);
    arms.push(upper);
  });

  // Feet.
  const legs=[];
  for(const s of [-1,1]){
    const leg=new THREE.Mesh(new THREE.CapsuleGeometry(.16,.56,6,10),skin);
    leg.position.set(s*.28,.62,.0);
    leg.castShadow=true;root.add(leg);legs.push(leg);
    const foot=new THREE.Mesh(new THREE.SphereGeometry(.22,14,10),skin);
    foot.position.set(s*.30,.28,-.06);foot.scale.set(1.2,.55,1.5);root.add(foot);
  }

  // Necklace / ornaments.
  const necklace=new THREE.Mesh(new THREE.TorusGeometry(.42,.035,8,32),gold);
  necklace.rotation.x=Math.PI/2;necklace.position.set(0,2.12,-.48);root.add(necklace);

  // Character-level shadow.
  const shadow=new THREE.Mesh(new THREE.CircleGeometry(.72,32),new THREE.MeshBasicMaterial({color:0x2d180f,transparent:true,opacity:.28}));
  shadow.rotation.x=-Math.PI/2;shadow.position.y=.02;shadow.scale.set(1.45,.72,1);root.add(shadow);

  root.userData.body=body;
  root.userData.head=head;
  root.userData.arms=arms;
  root.userData.legs=legs;
  root.userData.crown=crown;
  return root;
}

function createObstacle(type){
  const g=new THREE.Group();
  if(type==="log"){
    const m=new THREE.MeshStandardMaterial({color:0x704020,roughness:.95});
    const log=new THREE.Mesh(new THREE.CylinderGeometry(.52,.58,2.8,14),m);
    log.rotation.z=Math.PI/2;log.position.y=.62;g.add(log);
    return g;
  }
  if(type==="cart"){
    const body=new THREE.Mesh(new THREE.BoxGeometry(1.75,1.25,1.5),new THREE.MeshStandardMaterial({color:0xa9482e,roughness:.84}));
    body.position.y=.85;g.add(body);
    const roof=new THREE.Mesh(new THREE.BoxGeometry(1.95,.3,1.65),new THREE.MeshStandardMaterial({color:0xe0a144,roughness:.75}));
    roof.position.y=1.55;g.add(roof);
    return g;
  }
  if(type==="elephant"){
    const mat=new THREE.MeshStandardMaterial({color:0x7f8289,roughness:1});
    const body=new THREE.Mesh(new THREE.SphereGeometry(1,20,15),mat);
    body.scale.set(1.18,1,1.25);body.position.y=1.2;g.add(body);
    const head=new THREE.Mesh(new THREE.SphereGeometry(.62,18,14),mat);
    head.position.set(0,1.52,-.95);g.add(head);
    const trunk=new THREE.Mesh(new THREE.CapsuleGeometry(.12,.72,6,10),mat);
    trunk.position.set(0,1.06,-1.45);trunk.rotation.x=.1;g.add(trunk);
    const cloth=new THREE.Mesh(new THREE.BoxGeometry(1.9,.7,2.0),new THREE.MeshStandardMaterial({color:0xd24834,roughness:.78}));
    cloth.position.set(0,1.6,0);g.add(cloth);
    return g;
  }
  if(type==="lowBarrier"){
    for(const s of [-1,1]){
      const p=new THREE.Mesh(new THREE.CylinderGeometry(.12,.14,.9,10),new THREE.MeshStandardMaterial({color:0x5b3423,roughness:.95}));
      p.position.set(s*.76,.45,0);g.add(p);
    }
    const bar=new THREE.Mesh(new THREE.BoxGeometry(1.75,.38,.18),new THREE.MeshStandardMaterial({color:0xf2c34f,roughness:.85}));
    bar.position.y=.78;g.add(bar);
    return g;
  }
  const drum=new THREE.Mesh(new THREE.CylinderGeometry(.72,.72,.9,18),new THREE.MeshStandardMaterial({color:0xc54e35,roughness:.86}));
  drum.rotation.x=Math.PI/2;drum.position.y=.78;g.add(drum);
  return g;
}

function createModak(){
  const g=new THREE.Group();
  const mat=new THREE.MeshStandardMaterial({color:0xffc94f,roughness:.48,emissive:0x5d2700,emissiveIntensity:.25});
  const base=new THREE.Mesh(new THREE.SphereGeometry(.38,18,14),mat);g.add(base);
  const cone=new THREE.Mesh(new THREE.ConeGeometry(.34,.6,12),mat);cone.position.y=.4;g.add(cone);
  for(let i=0;i<5;i++){
    const ring=new THREE.Mesh(new THREE.TorusGeometry(.24+i*.018,.018,6,18),new THREE.MeshStandardMaterial({color:0xdf951f,roughness:.55}));
    ring.rotation.x=Math.PI/2;ring.position.y=.12+i*.1;g.add(ring);
  }
  return g;
}

function createDurva(){
  const g=new THREE.Group();
  for(let i=0;i<5;i++){
    const leaf=new THREE.Mesh(new THREE.CapsuleGeometry(.045,.45,6,8),new THREE.MeshStandardMaterial({color:0x4f9f5c,roughness:.92}));
    leaf.position.y=i*.05;leaf.rotation.z=(i-2)*.14;g.add(leaf);
  }
  return g;
}

function createPowerup(type){
  const g=new THREE.Group();
  const color=type==="magnet"?0xe14467:0x4caaff;
  const orb=new THREE.Mesh(new THREE.SphereGeometry(.46,18,14),new THREE.MeshStandardMaterial({color,emissive:color,emissiveIntensity:.5,roughness:.32,metalness:.2}));
  g.add(orb);
  const ring=new THREE.Mesh(new THREE.TorusGeometry(.58,.07,10,32),new THREE.MeshStandardMaterial({color:0xffffff,emissive:color,emissiveIntensity:1.1}));
  ring.rotation.x=Math.PI/2;g.add(ring);
  return g;
}

function random(a){return a[Math.floor(Math.random()*a.length)]}
function showMessage(t){
  const el=document.getElementById("message");el.textContent=t;el.style.opacity="1";el.style.transform="translate(-50%,-50%) scale(1)";
  clearTimeout(messageTimer);messageTimer=setTimeout(()=>{el.style.opacity="0";el.style.transform="translate(-50%,-50%) scale(.92)"},650);
}
function updateHUD(){
  document.getElementById("hearts").textContent="♥ ".repeat(lives).trim()||"—";
  document.getElementById("modaks").textContent=modaks;
  document.getElementById("durva").textContent=durva;
  document.getElementById("combo").textContent=combo;
  document.getElementById("score").textContent=String(Math.floor(score)).padStart(6,"0");
  document.getElementById("distance").textContent=Math.floor(distance);
  const n=Math.min(modaks,500);
  document.getElementById("missionCount").textContent=n;
  document.getElementById("barFill").style.width=(n/5)+"%";
}
function pulse(){ renderer.domElement.style.filter="brightness(1.15)"; setTimeout(()=>renderer.domElement.style.filter="",80); }

addEventListener("resize",()=>{
  camera.aspect=innerWidth/innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth,innerHeight);
});

function animate(){
  requestAnimationFrame(animate);
  const dt=Math.min(clock.getDelta(),.035);
  update(dt);
  renderer.render(scene,camera);
}
animate();
