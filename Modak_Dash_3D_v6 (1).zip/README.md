# Modak Dash v6 — 3D Ganesha Runner

This version replaces the flat Ganesha image with a fully procedural 3D Ganesha character.

Features:
- Third-person runner camera
- 3D stylized Ganesha with crown, ears, trunk, four arms, dhoti and ornaments
- Fast instant lane changes
- Running arm/leg animation
- Real jump arc
- Real slide/crouch animation
- House-lined Ganesh Chaturthi neighborhood
- Large Ganesh pandal landmark
- Modak combo, durva shield, magnet, obstacles
- Keyboard + click/touch lane controls

Run:

```bash
npm install
npm run dev
```

Open the Vite URL. Do not open index.html directly.
